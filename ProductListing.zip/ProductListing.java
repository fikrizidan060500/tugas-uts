package Products;

public class ProductListing {
    public static void main(String[] args) {
        Product product_a = new Product("product a");
        product_a.getProductListing(5, 15, 10);
    }
    
}
